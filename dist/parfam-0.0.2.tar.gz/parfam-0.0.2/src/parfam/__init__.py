import sys

print(f'Python interpreter: {sys.executable}')

from .parfamwrapper import ParFamWrapper